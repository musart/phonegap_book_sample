package com.PhoneGapTestApplication;

import com.phonegap.*;
import android.os.Bundle;

public class PhoneGapTestApplicationActivity extends DroidGap {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        super.init();
        super.setIntegerProperty("splashscreen", R.drawable.splash);
        super.loadUrl("file:///android_asset/www/index.html", 2000);
    }
}
package com.phonegap.file;

public class NoModificationAllowedException extends Exception {

	public NoModificationAllowedException(String message) {
		super(message);
	}

}

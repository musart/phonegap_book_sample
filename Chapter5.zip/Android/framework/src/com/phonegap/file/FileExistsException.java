package com.phonegap.file;

public class FileExistsException extends Exception {

	public FileExistsException(String msg) {
		super(msg);
	}

}

package com.phonegapmyplugin;

import org.json.JSONArray;
import org.json.JSONException;

import com.phonegap.api.Plugin;
import com.phonegap.api.PluginResult;

public class myPlugin extends Plugin {

	private String data = "";

	@Override
	public PluginResult execute(String action, JSONArray args, final String callbackId) {
		if (action.equals("setData")) {
			try {
				data = args.getString(0);
			} catch (JSONException e) {
				e.printStackTrace();
				return new PluginResult(PluginResult.Status.JSON_EXCEPTION);
			}
			return new PluginResult(PluginResult.Status.OK, "setData is called" + data);
		} else if (action.equals("getData")) {
			return new PluginResult(PluginResult.Status.OK, "getData is called" + data);
		}
		return null;
	}
}

var myPlugin = function() {
    this.setData = function(onSuccess, onError, data) {
        PhoneGap.exec(onSuccess, onError, "com.phonegap.plugin.myPlugin", "setData", [data]);
    };
    this.getData = function(onSuccess, onError, data) {
        PhoneGap.exec(onSuccess, onError, "com.phonegap.plugin.myPlugin", "getData", [data]);
    };
};

PhoneGap.addConstructor(function() {
    PhoneGap.addPlugin('myplugin', new myPlugin());
});
